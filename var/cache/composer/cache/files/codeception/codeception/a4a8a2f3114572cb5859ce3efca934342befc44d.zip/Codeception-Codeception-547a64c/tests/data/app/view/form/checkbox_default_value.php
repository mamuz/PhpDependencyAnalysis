<!DOCTYPE html>

<form>
    <input type="checkbox" name="checkbox1">
</form>
