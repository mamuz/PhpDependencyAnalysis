<html>
<body>
<form action="/form/complex" method="post">
    <div id="bmessage-topicslinks">
    <div class="checkbox"><label><input type="checkbox" name="BMessage[topicsLinks][]" value="1"> Label 1</label></div>
    <div class="checkbox"><label><input type="checkbox" name="BMessage[topicsLinks][]" value="2"> Label 2</label></div>
    <div class="checkbox"><label><input type="checkbox" name="BMessage[topicsLinks][]" value="3"> Label 3</label></div>
    <div class="checkbox"><label><input type="checkbox" name="BMessage[topicsLinks][]" value="4"> Label 4</label></div>
    </div>
    <input type="submit" value="Submit" />
</form>
</body>
</html>