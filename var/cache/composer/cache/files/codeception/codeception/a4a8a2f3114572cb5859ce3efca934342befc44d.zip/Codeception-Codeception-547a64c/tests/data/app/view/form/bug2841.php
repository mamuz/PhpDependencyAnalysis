<!doctype html>
<html>
    <head><title>hi</title></head>
    <body>
    <form name="form" action="/form/bug2841" method="post" enctype="multipart/form-data">
        <input name="in" type="text" id="texty">
        <button type="submit" name="submit-registration" id="submit-registration" class="submit-registration">CLICKY</button>
    </form>
    </body>
</html>
