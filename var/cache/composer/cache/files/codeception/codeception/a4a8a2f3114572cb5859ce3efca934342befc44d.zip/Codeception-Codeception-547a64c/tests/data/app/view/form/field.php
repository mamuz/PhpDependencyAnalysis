<html>
<body>
<form action="/form/complex" method="POST">
    <label for="name">Name</label>
    <label>
        <b>Other label</b>
        <div>
            <input name="othername">
        </div>
    </label>
    <input type="text" id="name" name="name" value="OLD_VALUE" />
    <input type="submit" value="Submit" />
</form>
</body>
</html>