<html>
<head>
	<style>
		body{padding:0;margin:0;}
		.myFloatBar{
			bottom:0;
			left:0;
			width:100%;
			position:fixed;
			background-color:#F00;
			height:500px;
		}
	</style>
</head>
<body>
<div class="myFloatBar">This bar is over the button that we want to click</div>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<form action="/form/button" method="POST">
	<input type="hidden" name="text" value="val" />
	<button type="submit" name="btn0" id="clickme">Submit</button>
</form>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
<p>Some Text</p>
</body>
</html>