<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<body>

<base href="/form/">

<p>
    <a href="example7">Relative Link</a>
</p>


<form action="example5" method="post">
    <input type="text" name="rus" value="Верно"/>
    <div id="button-container">
        <input type="submit" value="Relative Form"/>
    </div>
</form>

</body>
</html>
