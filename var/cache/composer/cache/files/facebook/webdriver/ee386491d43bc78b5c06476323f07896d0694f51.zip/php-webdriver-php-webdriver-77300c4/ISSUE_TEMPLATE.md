### What are you trying to achieve? (Expected behavior)
<!-- Please fill -->

### What do you get instead? (Actual behavior)
<!-- Please fill -->

### How could the issue be reproduced? (Steps to reproduce)
<!-- Please fill everything relevant - the exact code you use, how you initialize the WebDriver, HTML snippet or URL of the page where you encounter the issue etc. -->

```php
// You can insert your PHP code here (or remove this block if it is not relevant for the issue).
```

### Details
<!-- Please fill relevant following versions: -->

* Php-webdriver version: 
* PHP version: 
* Selenium server version: 
* Operating system: 
* Browser used + version: 
