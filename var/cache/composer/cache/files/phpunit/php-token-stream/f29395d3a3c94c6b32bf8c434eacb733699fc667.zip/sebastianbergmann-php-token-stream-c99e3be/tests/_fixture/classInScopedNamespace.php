<?php
namespace Foo\BarScoped {

    class TestClass {

    }

}

