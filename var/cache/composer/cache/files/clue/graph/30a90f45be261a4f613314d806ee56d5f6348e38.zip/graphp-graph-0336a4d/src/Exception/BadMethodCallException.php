<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class BadMethodCallException extends \BadMethodCallException implements Graph\Exception
{
}
