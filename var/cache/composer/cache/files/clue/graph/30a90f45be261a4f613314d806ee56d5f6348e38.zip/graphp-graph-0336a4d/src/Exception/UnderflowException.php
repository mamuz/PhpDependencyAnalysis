<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class UnderflowException extends \UnderflowException implements Graph\Exception
{
}
