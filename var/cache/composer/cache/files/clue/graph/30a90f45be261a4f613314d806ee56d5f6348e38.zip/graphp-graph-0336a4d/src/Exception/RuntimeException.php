<?php

namespace Fhaculty\Graph\Exception;

use Fhaculty\Graph;

class RuntimeException extends \RuntimeException implements Graph\Exception
{
}
