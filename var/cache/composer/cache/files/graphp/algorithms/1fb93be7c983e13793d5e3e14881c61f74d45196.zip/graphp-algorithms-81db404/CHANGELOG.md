# Changelog

## 0.8.1 (2015-03-08)

*   Support graph v0.9 (while keeping BC)
    ([#16](https://github.com/graphp/algorithms/pull/16))

*   Deprecate internal algorithm base classes
    ([#15](https://github.com/graphp/algorithms/pull/15))

## 0.8.0 (2015-02-25)

*   First tagged release, split off from [clue/graph](https://github.com/clue/graph) v0.8.0
    ([#1](https://github.com/graphp/algorithms/issues/1))
