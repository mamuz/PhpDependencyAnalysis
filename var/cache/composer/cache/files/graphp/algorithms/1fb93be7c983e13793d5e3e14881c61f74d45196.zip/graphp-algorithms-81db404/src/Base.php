<?php

namespace Graphp\Algorithms;

/**
 * @deprecated
 */
abstract class Base{ }
