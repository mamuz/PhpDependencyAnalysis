<?php

namespace PhpParser;

class ConstExprEvaluationException extends \Exception
{}
