<?php

namespace PharIo\Manifest;

class ManifestLoaderException extends \Exception implements Exception {
}
